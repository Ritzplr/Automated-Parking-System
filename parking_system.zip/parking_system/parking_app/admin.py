from django.contrib import admin
from .models import Parking,ParkingSpace, Distance

admin.site.register(Parking)
admin.site.register(ParkingSpace)
admin.site.register(Distance)
